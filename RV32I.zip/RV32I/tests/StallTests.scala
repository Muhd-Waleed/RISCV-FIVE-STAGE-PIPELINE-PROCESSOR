// See LICENSE.txt for license details.
package merl

import chisel3.iotesters.{PeekPokeTester, Driver, ChiselFlatSpec}

class StallTests(c: Stall) extends PeekPokeTester(c) {
    val EMrd   = 0
    val EMread = 2
    val IDrs1  = 2
    val IDrs2  = 1
    val out1 = 0
    val out2 = 0
    val out3 = 0
    poke(c.io.EXwrite,0)
    poke(c.io.EMread,EMread)
    poke(c.io.EMrd,EMrd)
    poke(c.io.IDrs1,IDrs1)
    poke(c.io.IDrs2,IDrs2)
    step(1)
    
}

class StallTester extends ChiselFlatSpec {
  behavior of "Stall"
  backends foreach {backend =>
    it should s"correctly add randomly generated numbers $backend" in {
      Driver(() => new Stall())(c => new StallTests(c)) should be (true)
    }
  }
}
