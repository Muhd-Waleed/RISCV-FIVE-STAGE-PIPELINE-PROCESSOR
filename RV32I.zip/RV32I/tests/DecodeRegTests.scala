// See LICENSE.txt for license details.
package merl
import chisel3.iotesters.{PeekPokeTester, Driver, ChiselFlatSpec}
class DecodeRegTests(c: DecodeReg) extends PeekPokeTester(c) {
     val din1   = 1
     val din2   = 1
     val din3   = 1
     val din4   = 1
     val din5   = 1
     val din6   = 1
     val din7   = 1
     val din8   = 1
     val din9   = 1
     val din10  = 1
     val din11  = 1
     val din12  = 1
     val din13  = 1
     val din14  = 1
     val din15  = 1
     val din16  = 1
     val din17  = 1
    poke(c.io.din1, din1)
    poke(c.io.din2, din2)
    poke(c.io.din3, din3)
    poke(c.io.din4, din4)
    poke(c.io.din5, din5)
    poke(c.io.din6, din6)
    poke(c.io.din7, din7)
    poke(c.io.din8, din8)
    poke(c.io.din9, din9)
    poke(c.io.din10,din10)
    poke(c.io.din11,din11)
    poke(c.io.din12,din11)
    poke(c.io.din13,din13)
    poke(c.io.din14,din14)
    poke(c.io.din15,din15)
    poke(c.io.din16,din16)
    poke(c.io.din17,din17)
    step(1)
    
}

class DecodeRegTester extends ChiselFlatSpec {
  behavior of "DecodeReg"
  backends foreach {backend =>
    it should s"correctly add randomly generated numbers $backend" in {
      Driver(() => new DecodeReg())(c => new DecodeRegTests(c)) should be (true)
    }
  }
}
