// See LICENSE.txt for license details.
package merl
import chisel3.iotesters.{PeekPokeTester, Driver, ChiselFlatSpec}
class WBregTests(c: WBreg) extends PeekPokeTester(c) {
    val win1   = 1
    val win2   = 1
    val win3   = 1
    val win4   = 1
    val win5   = 1
    val win6   = 1
    poke(c.io.win1,win1)
    poke(c.io.win2,win2)
    poke(c.io.win3,win3)
    poke(c.io.win4,win4)
    poke(c.io.win5,win5)
    poke(c.io.win6,1)
    step(1)
    
}

class WBregTester extends ChiselFlatSpec {
  behavior of "WBreg"
  backends foreach {backend =>
    it should s"correctly add randomly generated numbers $backend" in {
      Driver(() => new WBreg())(c => new WBregTests(c)) should be (true)
    }
  }
}
