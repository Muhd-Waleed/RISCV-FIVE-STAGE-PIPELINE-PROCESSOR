package merl
import chisel3.iotesters.{PeekPokeTester, Driver, ChiselFlatSpec}
class ForwardMTests(c: ForwardM) extends PeekPokeTester(c) {
  
  
    poke(c.io.EMrs2 ,1)
    poke(c.io.EMwrite,1)
    poke(c.io.MBread,1)
    poke(c.io.MBrd,1)
    step(1)
   // expect(c.io.out1,Out1)
    //expect(c.io.out2,)
}