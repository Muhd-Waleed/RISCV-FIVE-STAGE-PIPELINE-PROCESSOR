package merl
import chisel3.iotesters.{PeekPokeTester, Driver, ChiselFlatSpec}
class BranchesTests(c: Branches) extends PeekPokeTester(c)
{
    poke(c.io.in1 , 3)
    poke(c.io.in2 , 5)
    poke(c.io.control , 0)
    step(1)
}