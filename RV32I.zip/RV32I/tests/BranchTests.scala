// See LICENSE.txt for license details.
package merl
import chisel3.iotesters.{PeekPokeTester, Driver, ChiselFlatSpec}
class BranchTests(c: Branch) extends PeekPokeTester(c) {
        val in1      = 1
		val in2      = 1
        val func3    = 1
    poke(c.io.in1,in1)
    poke(c.io.in2,in2)
    poke(c.io.func3,func3)
    step(1)
    
}

class BranchTester extends ChiselFlatSpec {
  behavior of "Branch"
  backends foreach {backend =>
    it should s"correctly add randomly generated numbers $backend" in {
      Driver(() => new Branch())(c => new BranchTests(c)) should be (true)
    }
  }
}
