// See LICENSE.txt for license details.
package merl
import chisel3.iotesters.{PeekPokeTester, Driver, ChiselFlatSpec}
class ExregTests(c: Exreg) extends PeekPokeTester(c) {
    val ein1   = 1
    val ein2   = 1
    val ein3   = 1
    val ein4   = 1
    val ein5   = 1
    val ein6   = 1
    val ein7   = 1
    val ein8   = 1
    poke(c.io.ein1,ein1)
    poke(c.io.ein2,ein2)
    poke(c.io.ein3,ein3)
    poke(c.io.ein4,ein4)
    poke(c.io.ein5,ein5)
    poke(c.io.ein6,ein6)
    poke(c.io.ein7,ein7)
    poke(c.io.ein8,ein8)
    step(1)
    
}

class ExregTester extends ChiselFlatSpec {
  behavior of "Exreg"
  backends foreach {backend =>
    it should s"correctly add randomly generated numbers $backend" in {
      Driver(() => new Exreg())(c => new ExregTests(c)) should be (true)
    }
  }
}
