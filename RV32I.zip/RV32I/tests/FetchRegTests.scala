// See LICENSE.txt for license details.
package merl
import chisel3.iotesters.{PeekPokeTester, Driver, ChiselFlatSpec}
class FetchRegTests(c: FetchReg) extends PeekPokeTester(c) {
    val fin1 = 1
    val fin2 = 1
    val fin3 = 1
    val fin4 = 1
    poke(c.io.fin1,fin1)
    poke(c.io.fin2,fin2)
    poke(c.io.fin3,fin3)
    poke(c.io.fin4,fin4)
    step(1)
    
}

class FetchRegTester extends ChiselFlatSpec {
  behavior of "FetchReg"
  backends foreach {backend =>
    it should s"correctly add randomly generated numbers $backend" in {
      Driver(() => new FetchReg())(c => new FetchRegTests(c)) should be (true)
    }
  }
}
