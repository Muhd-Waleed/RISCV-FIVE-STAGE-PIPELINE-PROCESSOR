// See LICENSE.txt for license details.
package merl

import chisel3.iotesters.{PeekPokeTester, Driver, ChiselFlatSpec}

class TopTests(c: Top) extends PeekPokeTester(c) {
    step(1)
    step(1)
    step(1)
    step(1)
    step(1)
     step(1)
    step(1)
    step(1)
    step(1)
    step(1)
     step(1)
    step(1)
    step(1)
    step(1)
    step(1)
     step(1)
    step(1)
    step(1)
    step(1)
    step(50)
    



}

class TopTester extends ChiselFlatSpec {
  behavior of "Top"
  backends foreach {backend =>
    it should s"correctly add randomly generated numbers $backend" in {
      Driver(() => new Top())(c => new TopTests(c)) should be (true)
    }
  }
}
