package merl
import chisel3.iotesters.{PeekPokeTester, Driver, ChiselFlatSpec}
class BranchForwardTests(c: BranchForward) extends PeekPokeTester(c) {
  
    poke(c.io.EXerd, 1)
  //   poke(c.io.EMwrt, 1)
    poke(c.io.EXMemrd ,1)
    poke(c.io. IDRs1,1)
    poke(c.io.IDRs2,1)
    poke(c.io.Cbranch,0)
    poke(c.io.MemWBrd,1)
    step(1)
   // expect(c.io.out1,Out1)
    //expect(c.io.out2,)
}
